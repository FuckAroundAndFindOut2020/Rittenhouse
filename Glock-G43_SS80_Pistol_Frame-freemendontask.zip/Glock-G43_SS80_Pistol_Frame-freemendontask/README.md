# Glock G43 SS80 Pistol Frame 

#### Author
FreeMenDontAsk 

#### Description
This is a (Glock) G43 SS80 Pistol Frame (Lower) by Freemandontask. To complete the lower you will need the SS80 Builders Tool Set found [here](https://www.glockstore.com/SS80-Build-Set). This frame was inspired by the Glockstore SS80 80% Lower.

Make your own single stack frame that you complete with Glock 43 parts. This SS80 Frame is compatible with parts designed for the Glock 43.

#### Parts Required
* G43 OEM Parts Kit
* SS80 Builders Tool Set

#### Print Settings
* 99% infill printed upside down with support

##### Assembly
* Some hand filling and fitting required
* Assembles like a standard SS80 G43
