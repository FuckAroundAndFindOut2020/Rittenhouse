# AR-15 .22 LR Lower Receiver

#### Author
FreeMenDontAsk

#### Version
1.0

#### Description
This is an AR-15 .22 LR lower receiver by FreeMenDontAsk.

#### Printing
* Print lower 99% infill quality PLA with support
* Print both the brace and buffer tube without supports standing upright
* Print the brace at 99% infill concentric, buffer tube 40% infill lines shell 4 outer walls
