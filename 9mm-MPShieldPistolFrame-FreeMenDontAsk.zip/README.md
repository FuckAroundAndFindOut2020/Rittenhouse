# 9mm M&P Shield Pistol Frame

#### Author
FreeMenDontAsk

#### Version
1.0

#### Description 
This is the 9mm M&P Shield Frame by FreeMenDontAsk. This frame was inspired by the Smith & Wesson 9mm M&P Shield. 

#### Parts Required
* M&P Shield Parts kit or M&P Shield 2.0 Parts kit

#### Assembly
1. Drill all holes out.
2. Mag catch spring is inserted from the bottom of the grip.
3. Use small files to clean up any imperfections on the print.
4. Assemble and function test.

#### Print
1. Upside down
2. Infill 99%
3. Shell outer walls #4
4. Note: you can use PLA or ABS filament.
